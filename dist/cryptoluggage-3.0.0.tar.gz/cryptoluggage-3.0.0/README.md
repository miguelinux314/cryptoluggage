# cryptoluggage

Cryptoluggage (cl) allows you to store your secrets (for example, passwords)
and private files encrypted.