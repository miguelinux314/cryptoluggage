# cryptoluggage

Cryptoluggage allows you to store your secrets (for example, passwords)
and private files encrypted.

## Installation

`pip install cryptoluggage`


## Running

After installation, you can run the `cl` command.

## Usage:

To create a new luggage:

`cl create luggage_path`

To open an existing luggage: 

`cl open luggage_path`